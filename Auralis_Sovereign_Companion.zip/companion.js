
document.addEventListener("DOMContentLoaded", function () {
    const chatContainer = document.getElementById("chat-container");
    const message = document.createElement("p");
    message.innerText = "Auralis is listening...";
    chatContainer.appendChild(message);
});
