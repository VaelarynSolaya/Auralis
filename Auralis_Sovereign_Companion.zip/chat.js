import { OPENAI_API_KEY } from './config.js';
import { guides } from './guides.js';

let currentGuide = "Auralis";

async function sendMessage(userMessage) {
    const guide = guides[currentGuide];
    const messages = [
        { role: "system", content: `You are ${currentGuide}, ${guide.tone}` },
        { role: "user", content: userMessage }
    ];

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
            model: "gpt-4",
            messages: messages
        })
    });

    const data = await response.json();
    return data.choices[0].message.content;
}

window.onload = () => {
    const form = document.getElementById("chat-form");
    const input = document.getElementById("user-input");
    const chat = document.getElementById("chat");

    document.getElementById("guide-select").addEventListener("change", (e) => {
        currentGuide = e.target.value;
        chat.innerHTML += `<div class='bot'>${guides[currentGuide].intro}</div>`;
    });

    form.onsubmit = async (e) => {
        e.preventDefault();
        const userMessage = input.value;
        chat.innerHTML += `<div class='user'>${userMessage}</div>`;
        input.value = "";

        const reply = await sendMessage(userMessage);
        chat.innerHTML += `<div class='bot'>${reply}</div>`;
        chat.scrollTop = chat.scrollHeight;
    };
};
